import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, Sparkles } from "lucide-react";

const projectTypes = ["AI/ML", "Web App", "Data Analysis", "Mobile App", "DevOps", "Backend Service"];
const developmentStyles = ["Rapid Prototyping", "Enterprise-Grade", "Open-Source Focus", "Cost-Sensitive", "Performance-Critical"];
const scalabilityOptions = ["High Scale", "Low Latency", "Simple/Local", "Distributed"];
const featureOptions = [
  "Vector Search",
  "Real-time Data",
  "Payment Processing",
  "Full-Text Search",
  "Caching",
  "Easy to Learn",
  "Strong Community",
  "Customizable",
];

export default function Home() {
  const [projectType, setProjectType] = useState<string>("");
  const [developmentStyle, setDevelopmentStyle] = useState<string>("");
  const [scalability, setScalability] = useState<string>("");
  const [selectedFeatures, setSelectedFeatures] = useState<string[]>([]);

  const recommendationsQuery = trpc.recommendations.generateRecommendations.useQuery(
    {
      projectType: projectType || undefined,
      developmentStyle: developmentStyle || undefined,
      scalability: scalability || undefined,
      specificFeatures: selectedFeatures.length > 0 ? selectedFeatures : undefined,
    },
    {
      enabled: projectType !== "" || developmentStyle !== "" || scalability !== "" || selectedFeatures.length > 0,
    }
  );

  const toggleFeature = (feature: string) => {
    setSelectedFeatures((prev) => (prev.includes(feature) ? prev.filter((f) => f !== feature) : [...prev, feature]));
  };

  const handleReset = () => {
    setProjectType("");
    setDevelopmentStyle("");
    setScalability("");
    setSelectedFeatures([]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Sparkles className="w-8 h-8 text-blue-600" />
            <h1 className="text-4xl md:text-5xl font-bold text-slate-900">Product Recommendation Agent</h1>
          </div>
          <p className="text-lg text-slate-600">Discover the best tools and technologies for your project</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Input Panel */}
          <div className="lg:col-span-1">
            <Card className="sticky top-8">
              <CardHeader>
                <CardTitle>Your Preferences</CardTitle>
                <CardDescription>Tell us about your project needs</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Project Type */}
                <div className="space-y-2">
                  <Label htmlFor="project-type" className="text-sm font-medium">
                    Project Type
                  </Label>
                  <Select value={projectType} onValueChange={setProjectType}>
                    <SelectTrigger id="project-type">
                      <SelectValue placeholder="Select a type..." />
                    </SelectTrigger>
                    <SelectContent>
                      {projectTypes.map((type) => (
                        <SelectItem key={type} value={type}>
                          {type}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Development Style */}
                <div className="space-y-2">
                  <Label htmlFor="dev-style" className="text-sm font-medium">
                    Development Style
                  </Label>
                  <Select value={developmentStyle} onValueChange={setDevelopmentStyle}>
                    <SelectTrigger id="dev-style">
                      <SelectValue placeholder="Select a style..." />
                    </SelectTrigger>
                    <SelectContent>
                      {developmentStyles.map((style) => (
                        <SelectItem key={style} value={style}>
                          {style}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Scalability */}
                <div className="space-y-2">
                  <Label htmlFor="scalability" className="text-sm font-medium">
                    Scalability Needs
                  </Label>
                  <Select value={scalability} onValueChange={setScalability}>
                    <SelectTrigger id="scalability">
                      <SelectValue placeholder="Select a level..." />
                    </SelectTrigger>
                    <SelectContent>
                      {scalabilityOptions.map((option) => (
                        <SelectItem key={option} value={option}>
                          {option}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Specific Features */}
                <div className="space-y-3">
                  <Label className="text-sm font-medium">Specific Features</Label>
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {featureOptions.map((feature) => (
                      <div key={feature} className="flex items-center space-x-2">
                        <Checkbox
                          id={feature}
                          checked={selectedFeatures.includes(feature)}
                          onCheckedChange={() => toggleFeature(feature)}
                        />
                        <Label htmlFor={feature} className="text-sm font-normal cursor-pointer">
                          {feature}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <Button onClick={handleReset} variant="outline" className="w-full">
                  Reset Preferences
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Results Panel */}
          <div className="lg:col-span-2">
            {recommendationsQuery.isLoading && (
              <div className="flex items-center justify-center h-96">
                <div className="text-center">
                  <Loader2 className="w-8 h-8 animate-spin mx-auto mb-2 text-blue-600" />
                  <p className="text-slate-600">Generating recommendations...</p>
                </div>
              </div>
            )}

            {recommendationsQuery.isError && (
              <Card className="border-red-200 bg-red-50">
                <CardContent className="pt-6">
                  <p className="text-red-600">Error loading recommendations. Please try again.</p>
                </CardContent>
              </Card>
            )}

            {recommendationsQuery.data && Object.keys(recommendationsQuery.data).length > 0 ? (
              <div className="space-y-4">
                <h2 className="text-2xl font-bold text-slate-900 mb-6">Recommended Tools</h2>
                {Object.entries(recommendationsQuery.data).map(([categoryId, recommendation]) => (
                  <Card key={categoryId} className="hover:shadow-lg transition-shadow">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div>
                          <CardTitle className="text-xl">{recommendation.tool.name}</CardTitle>
                          <CardDescription>{recommendation.tool.type}</CardDescription>
                        </div>
                        <div className="text-right">
                          <div className="text-3xl font-bold text-blue-600">{Math.round(recommendation.score)}%</div>
                          <div className="text-xs text-slate-500">Match Score</div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <p className="text-slate-700">{recommendation.reasoning}</p>

                      {recommendation.tool.description && (
                        <p className="text-sm text-slate-600">{recommendation.tool.description}</p>
                      )}

                      {recommendation.matchedFeatures.length > 0 && (
                        <div>
                          <h4 className="text-sm font-semibold text-slate-900 mb-2">Matched Features:</h4>
                          <div className="flex flex-wrap gap-2">
                            {recommendation.matchedFeatures.map((feature) => (
                              <span key={feature} className="inline-block bg-blue-100 text-blue-800 text-xs px-3 py-1 rounded-full">
                                {feature}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}

                      {recommendation.tool.keyFeatures && (
                        <div>
                          <h4 className="text-sm font-semibold text-slate-900 mb-2">Key Features:</h4>
                          <div className="flex flex-wrap gap-2">
                            {JSON.parse(recommendation.tool.keyFeatures).map((feature: string) => (
                              <span key={feature} className="inline-block bg-slate-200 text-slate-800 text-xs px-2 py-1 rounded">
                                {feature}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}

                      {recommendation.tool.website && (
                        <a
                          href={recommendation.tool.website}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-block text-blue-600 hover:text-blue-800 text-sm font-medium"
                        >
                          Visit Website →
                        </a>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <Card className="border-dashed">
                <CardContent className="pt-12 pb-12 text-center">
                  <p className="text-slate-600 mb-2">Select your preferences to get recommendations</p>
                  <p className="text-sm text-slate-500">Choose at least one option to see personalized tool suggestions</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
