import { drizzle } from "drizzle-orm/mysql2";
import { categories, tools } from "./drizzle/schema.js";
import { eq } from "drizzle-orm";
import mysql from "mysql2/promise";

const DATABASE_URL = process.env.DATABASE_URL;

async function seed() {
  if (!DATABASE_URL) {
    console.error("DATABASE_URL not set");
    process.exit(1);
  }

  const connection = await mysql.createConnection(DATABASE_URL);
  const db = drizzle(connection);

  try {
    // Check if categories already exist
    const existingCategories = await db.select().from(categories);
    if (existingCategories.length > 0) {
      console.log("Database already seeded");
      await connection.end();
      return;
    }

    // Insert categories
    const categoryNames = ["AI Models", "Frameworks", "Vector Databases", "APIs", "UI/Styling", "Databases"];
    const categoryIds = {};

    for (const name of categoryNames) {
      await db.insert(categories).values({ name, description: `${name} for development` });
      const inserted = await db.select().from(categories).where(eq(categories.name, name)).limit(1);
      if (inserted.length > 0) {
        categoryIds[name] = inserted[0].id;
      }
    }

    // Insert tools
    const toolsData = [
      {
        category: "AI Models",
        items: [
          { name: "GPT-4o", type: "Proprietary LLM", features: ["Multimodal", "Fast", "High-quality"], pros: ["Best performance"], cons: ["Expensive"], bestFor: ["Complex tasks", "Production"] },
          { name: "Claude 3.5 Sonnet", type: "Proprietary LLM", features: ["Strong reasoning", "Large context"], pros: ["Good for coding"], cons: ["Slower"], bestFor: ["Code generation", "Analysis"] },
          { name: "Llama 3.3 70B", type: "Open-Source LLM", features: ["Customizable", "Strong performance"], pros: ["Free", "Open"], cons: ["Requires infrastructure"], bestFor: ["Custom deployments", "Cost-sensitive"] },
        ]
      },
      {
        category: "Frameworks",
        items: [
          { name: "React", type: "Frontend Library", features: ["Component-based", "Virtual DOM"], pros: ["Large ecosystem"], cons: ["Steep learning curve"], bestFor: ["Web apps", "SPAs"] },
          { name: "Vue.js", type: "Frontend Framework", features: ["Progressive", "Easy to learn"], pros: ["Flexible"], cons: ["Smaller ecosystem"], bestFor: ["Rapid development", "Learning"] },
          { name: "Next.js", type: "Full-Stack Framework", features: ["SSR", "SSG", "API routes"], pros: ["All-in-one"], cons: ["Opinionated"], bestFor: ["Full-stack apps", "SEO-critical sites"] },
        ]
      },
      {
        category: "Vector Databases",
        items: [
          { name: "Pinecone", type: "Managed Vector DB", features: ["Serverless", "High-scale"], pros: ["Easy to use"], cons: ["Proprietary", "Expensive"], bestFor: ["Production RAG", "Scale"] },
          { name: "Qdrant", type: "Open-Source Vector DB", features: ["High-performance", "Rich filtering"], pros: ["Open", "Fast"], cons: ["Self-hosted"], bestFor: ["Custom deployments", "Filtering"] },
          { name: "Chroma", type: "Open-Source Vector DB", features: ["Lightweight", "Python-native"], pros: ["Easy to start"], cons: ["Limited scale"], bestFor: ["Prototyping", "Small projects"] },
        ]
      },
      {
        category: "APIs",
        items: [
          { name: "Stripe API", type: "Payment Processing", features: ["Comprehensive", "Easy integration"], pros: ["Well-documented"], cons: ["Fees"], bestFor: ["E-commerce", "Payments"] },
          { name: "GitHub API", type: "Version Control", features: ["Repository access", "Issue tracking"], pros: ["Powerful"], cons: ["Complex"], bestFor: ["DevOps", "Automation"] },
          { name: "OpenWeatherMap API", type: "Weather Data", features: ["Real-time", "Forecast"], pros: ["Simple"], cons: ["Rate limits"], bestFor: ["Weather apps", "Data"] },
        ]
      },
      {
        category: "UI/Styling",
        items: [
          { name: "Tailwind CSS", type: "Utility-First CSS", features: ["Rapid development", "Customizable"], pros: ["Small bundle"], cons: ["Learning curve"], bestFor: ["Modern UIs", "Design systems"] },
          { name: "Material UI", type: "Component Library", features: ["React components", "Material Design"], pros: ["Large set"], cons: ["Opinionated"], bestFor: ["Enterprise apps", "Consistency"] },
          { name: "Shadcn/ui", type: "Component Library", features: ["Copy-paste", "Tailwind-based"], pros: ["Flexible"], cons: ["Manual updates"], bestFor: ["Custom designs", "Control"] },
        ]
      },
      {
        category: "Databases",
        items: [
          { name: "PostgreSQL", type: "Relational (SQL)", features: ["ACID compliant", "Extensible"], pros: ["Mature", "Open"], cons: ["Complex setup"], bestFor: ["Enterprise", "Complex queries"] },
          { name: "MongoDB", type: "Document (NoSQL)", features: ["Flexible schema", "Horizontal scaling"], pros: ["Easy to use"], cons: ["Less consistent"], bestFor: ["Rapid dev", "Flexible data"] },
          { name: "Redis", type: "Key-Value (NoSQL)", features: ["In-memory", "Fast"], pros: ["Ultra-fast"], cons: ["Limited persistence"], bestFor: ["Caching", "Real-time"] },
        ]
      },
    ];

    for (const category of toolsData) {
      const categoryId = categoryIds[category.category];
      if (!categoryId) continue;

      for (const tool of category.items) {
        await db.insert(tools).values({
          categoryId,
          name: tool.name,
          type: tool.type,
          keyFeatures: JSON.stringify(tool.features),
          pros: JSON.stringify(tool.pros),
          cons: JSON.stringify(tool.cons),
          bestFor: JSON.stringify(tool.bestFor),
        });
      }
    }

    console.log("Database seeded successfully");
  } catch (error) {
    console.error("Error seeding database:", error);
    process.exit(1);
  } finally {
    await connection.end();
  }
}

seed();
