import { describe, it, expect } from "vitest";
import { calculateMatchScore, generateRecommendations } from "./recommendation-engine";
import type { Tool } from "../drizzle/schema";

describe("Recommendation Engine", () => {
  const mockTool: Tool = {
    id: 1,
    categoryId: 1,
    name: "React",
    description: "A JavaScript library for building user interfaces",
    type: "Frontend Library",
    keyFeatures: JSON.stringify(["Component-based", "Virtual DOM", "Easy to learn"]),
    pros: JSON.stringify(["Large ecosystem", "High demand"]),
    cons: JSON.stringify(["Steep learning curve"]),
    bestFor: JSON.stringify(["Web apps", "SPAs", "Rapid development"]),
    website: "https://react.dev",
    createdAt: new Date(),
  };

  const mockVectorDBTool: Tool = {
    id: 2,
    categoryId: 3,
    name: "Pinecone",
    description: "Managed vector database",
    type: "Managed Vector DB",
    keyFeatures: JSON.stringify(["Serverless", "High-scale", "Easy to use"]),
    pros: JSON.stringify(["Fully managed", "No infrastructure"]),
    cons: JSON.stringify(["Expensive", "Vendor lock-in"]),
    bestFor: JSON.stringify(["Production RAG", "Vector search", "Scale"]),
    website: "https://pinecone.io",
    createdAt: new Date(),
  };

  describe("calculateMatchScore", () => {
    it("should return 0 for no matching preferences", () => {
      const score = calculateMatchScore(mockTool, {});
      expect(score).toBe(0);
    });

    it("should score higher when project type matches best-for use cases", () => {
      const score = calculateMatchScore(mockTool, {
        projectType: "Web App",
      });
      expect(score).toBeGreaterThan(0);
      expect(score).toBeLessThanOrEqual(100);
    });

    it("should score rapid prototyping development style for frameworks", () => {
      const score = calculateMatchScore(mockTool, {
        developmentStyle: "Rapid Prototyping",
      });
      expect(score).toBeGreaterThan(0);
    });

    it("should score vector search feature for vector databases", () => {
      const score = calculateMatchScore(mockVectorDBTool, {
        specificFeatures: ["Vector Search"],
      });
      expect(score).toBeGreaterThan(0);
    });

    it("should accumulate scores for multiple matching preferences", () => {
      const singleScore = calculateMatchScore(mockTool, {
        projectType: "Web App",
      });

      const multiScore = calculateMatchScore(mockTool, {
        projectType: "Web App",
        developmentStyle: "Rapid Prototyping",
        specificFeatures: ["Easy to learn"],
      });

      expect(multiScore).toBeGreaterThanOrEqual(singleScore);
    });

    it("should cap score at 100", () => {
      const score = calculateMatchScore(mockTool, {
        projectType: "Web App",
        developmentStyle: "Rapid Prototyping",
        scalability: "High Scale",
        specificFeatures: ["Component-based", "Virtual DOM", "Easy to learn"],
      });

      expect(score).toBeLessThanOrEqual(100);
    });

    it("should handle missing JSON fields gracefully", () => {
      const toolWithoutFeatures: Tool = {
        ...mockTool,
        keyFeatures: null,
        bestFor: null,
      };

      const score = calculateMatchScore(toolWithoutFeatures, {
        projectType: "Web App",
      });

      expect(score).toBeGreaterThanOrEqual(0);
      expect(score).toBeLessThanOrEqual(100);
    });
  });

  describe("generateRecommendations", () => {
    it("should return recommendations for tools with scores", () => {
      const toolsByCategory = {
        "1": [mockTool],
        "3": [mockVectorDBTool],
      };

      const recommendations = generateRecommendations(toolsByCategory, {
        projectType: "Web App",
      });

      expect(Object.keys(recommendations).length).toBeGreaterThan(0);
    });

    it("should select the highest-scoring tool for each category", () => {
      const tool1: Tool = { ...mockTool, id: 1, name: "Tool1", bestFor: JSON.stringify(["Other"]) };
      const tool2: Tool = { ...mockTool, id: 2, name: "Tool2", bestFor: JSON.stringify(["Web apps"]) };

      const toolsByCategory = {
        "1": [tool1, tool2],
      };

      const recommendations = generateRecommendations(toolsByCategory, {
        projectType: "Web App",
      });

      expect(recommendations["1"]).toBeDefined();
      expect(recommendations["1"].tool.name).toBe("Tool2");
      expect(recommendations["1"].score).toBeGreaterThan(0);
    });

    it("should include reasoning for each recommendation", () => {
      const toolsByCategory = {
        "1": [mockTool],
      };

      const recommendations = generateRecommendations(toolsByCategory, {
        projectType: "Web App",
        developmentStyle: "Rapid Prototyping",
      });

      expect(recommendations["1"].reasoning).toBeDefined();
      expect(recommendations["1"].reasoning.length).toBeGreaterThan(0);
    });

    it("should handle empty tool categories", () => {
      const toolsByCategory = {
        "1": [],
      };

      const recommendations = generateRecommendations(toolsByCategory, {
        projectType: "Web App",
      });

      expect(Object.keys(recommendations).length).toBe(0);
    });

    it("should generate matched features list", () => {
      const toolsByCategory = {
        "1": [mockTool],
      };

      const recommendations = generateRecommendations(toolsByCategory, {
        projectType: "Web App",
        specificFeatures: ["Component-based"],
      });

      expect(recommendations["1"].matchedFeatures).toBeDefined();
      expect(Array.isArray(recommendations["1"].matchedFeatures)).toBe(true);
    });
  });
});
