import { Tool } from "../drizzle/schema";

export interface UserPreferences {
  projectType?: string; // e.g., "AI/ML", "Web App", "Data Analysis"
  developmentStyle?: string; // e.g., "Rapid Prototyping", "Enterprise-Grade", "Open-Source Focus"
  scalability?: string; // e.g., "High Scale", "Low Latency", "Simple/Local"
  specificFeatures?: string[]; // e.g., ["Vector Search", "Real-time", "Payment Processing"]
}

export interface RecommendationResult {
  tool: Tool;
  score: number;
  matchedFeatures: string[];
  reasoning: string;
}

/**
 * Calculate a match score between user preferences and a tool
 * Score is based on how many features align with preferences
 */
export function calculateMatchScore(tool: Tool, preferences: UserPreferences): number {
  let score = 0;
  const matchedFeatures: string[] = [];

  // Parse tool features
  let toolFeatures: string[] = [];
  let toolBestFor: string[] = [];
  let toolType: string = tool.type || "";

  try {
    if (tool.keyFeatures) {
      toolFeatures = JSON.parse(tool.keyFeatures);
    }
    if (tool.bestFor) {
      toolBestFor = JSON.parse(tool.bestFor);
    }
  } catch (e) {
    console.error("Error parsing tool features:", e);
  }

  // Match project type with tool's best-for use cases
  if (preferences.projectType) {
    const projectLower = preferences.projectType.toLowerCase();
    const matchingUseCase = toolBestFor.find((use) => use.toLowerCase().includes(projectLower));
    if (matchingUseCase) {
      score += 30;
      matchedFeatures.push(`Best for: ${matchingUseCase}`);
    }
  }

  // Match development style with tool type or features
  if (preferences.developmentStyle) {
    const styleLower = preferences.developmentStyle.toLowerCase();
    if (styleLower.includes("rapid") && (toolFeatures.some((f) => f.toLowerCase().includes("easy")) || toolType.includes("Framework"))) {
      score += 20;
      matchedFeatures.push("Supports rapid development");
    }
    if (styleLower.includes("enterprise") && toolType.includes("Enterprise")) {
      score += 20;
      matchedFeatures.push("Enterprise-grade");
    }
    if (styleLower.includes("open-source") && toolType.includes("Open-Source")) {
      score += 25;
      matchedFeatures.push("Open-source");
    }
  }

  // Match scalability with tool features
  if (preferences.scalability) {
    const scalabilityLower = preferences.scalability.toLowerCase();
    if (scalabilityLower.includes("high") && (toolFeatures.some((f) => f.toLowerCase().includes("scale")) || toolFeatures.some((f) => f.toLowerCase().includes("distributed")))) {
      score += 25;
      matchedFeatures.push("High scalability");
    }
    if (scalabilityLower.includes("low latency") && toolFeatures.some((f) => f.toLowerCase().includes("fast"))) {
      score += 20;
      matchedFeatures.push("Low latency");
    }
    if (scalabilityLower.includes("simple") && toolFeatures.some((f) => f.toLowerCase().includes("lightweight"))) {
      score += 15;
      matchedFeatures.push("Lightweight");
    }
  }

  // Match specific features
  if (preferences.specificFeatures && preferences.specificFeatures.length > 0) {
    for (const feature of preferences.specificFeatures) {
      const featureLower = feature.toLowerCase();
      const matchedFeature = toolFeatures.find((f) => f.toLowerCase().includes(featureLower) || featureLower.includes(f.toLowerCase()));
      if (matchedFeature) {
        score += 20;
        matchedFeatures.push(matchedFeature);
      }
      const matchedUseCase = toolBestFor.find((u) => u.toLowerCase().includes(featureLower) || featureLower.includes(u.toLowerCase()));
      if (matchedUseCase) {
        score += 15;
        matchedFeatures.push(`Use case: ${matchedUseCase}`);
      }
    }
  }

  return Math.min(score, 100); // Cap score at 100
}

/**
 * Generate recommendations for each category based on user preferences
 */
export function generateRecommendations(toolsByCategory: Record<string, Tool[]>, preferences: UserPreferences): Record<string, RecommendationResult> {
  const recommendations: Record<string, RecommendationResult> = {};

  for (const [category, tools] of Object.entries(toolsByCategory)) {
    let bestTool: Tool | null = null;
    let bestScore = 0;
    let bestMatchedFeatures: string[] = [];

    for (const tool of tools) {
      const score = calculateMatchScore(tool, preferences);
      if (score > bestScore) {
        bestScore = score;
        bestTool = tool;
        bestMatchedFeatures = [];

        // Recalculate to get matched features
        const result = calculateMatchScore(tool, preferences);
        // Extract matched features from the scoring logic
        let toolFeatures: string[] = [];
        let toolBestFor: string[] = [];
        try {
          if (tool.keyFeatures) {
            toolFeatures = JSON.parse(tool.keyFeatures);
          }
          if (tool.bestFor) {
            toolBestFor = JSON.parse(tool.bestFor);
          }
        } catch (e) {
          // Silently fail
        }

        // Collect matched features
        if (preferences.projectType) {
          const projectLower = preferences.projectType.toLowerCase();
          const matchingUseCase = toolBestFor.find((use) => use.toLowerCase().includes(projectLower));
          if (matchingUseCase) {
            bestMatchedFeatures.push(`Best for: ${matchingUseCase}`);
          }
        }

        if (preferences.specificFeatures) {
          for (const feature of preferences.specificFeatures) {
            const featureLower = feature.toLowerCase();
            const matchedFeature = toolFeatures.find((f) => f.toLowerCase().includes(featureLower));
            if (matchedFeature) {
              bestMatchedFeatures.push(matchedFeature);
            }
          }
        }
      }
    }

    if (bestTool) {
      const reasoning = generateReasoning(bestTool, preferences, bestMatchedFeatures);
      recommendations[category] = {
        tool: bestTool,
        score: bestScore,
        matchedFeatures: bestMatchedFeatures,
        reasoning,
      };
    }
  }

  return recommendations;
}

/**
 * Generate human-readable reasoning for why a tool was recommended
 */
function generateReasoning(tool: Tool, preferences: UserPreferences, matchedFeatures: string[]): string {
  const reasons: string[] = [];

  if (preferences.projectType) {
    reasons.push(`suitable for ${preferences.projectType} projects`);
  }

  if (preferences.developmentStyle) {
    reasons.push(`aligns with ${preferences.developmentStyle} approach`);
  }

  if (matchedFeatures.length > 0) {
    reasons.push(`offers ${matchedFeatures.slice(0, 2).join(" and ")}`);
  }

  if (reasons.length === 0) {
    reasons.push("a solid choice for your needs");
  }

  return `${tool.name} is ${reasons.join(", ")}.`;
}
