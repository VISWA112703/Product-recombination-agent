import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { getCategories, getAllTools, createUserPreference, saveRecommendation } from "./db";
import { generateRecommendations } from "./recommendation-engine";
import { tools } from "../drizzle/schema";
import { eq } from "drizzle-orm";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  recommendations: router({
    getCategories: publicProcedure.query(async () => {
      return await getCategories();
    }),

    getTools: publicProcedure.query(async () => {
      return await getAllTools();
    }),

    getToolsByCategory: publicProcedure
      .input(z.object({ categoryId: z.number() }))
      .query(async ({ input }) => {
        const db = await import("./db").then((m) => m.getDb());
        if (!db) return [];
        return db.select().from(tools).where(eq(tools.categoryId, input.categoryId));
      }),

    generateRecommendations: publicProcedure
      .input(
        z.object({
          projectType: z.string().optional(),
          developmentStyle: z.string().optional(),
          scalability: z.string().optional(),
          specificFeatures: z.array(z.string()).optional(),
        })
      )
      .query(async ({ input }) => {
        const allTools = await getAllTools();

        const toolsByCategory: Record<string, typeof allTools> = {};
        for (const tool of allTools) {
          const categoryId = tool.categoryId.toString();
          if (!toolsByCategory[categoryId]) {
            toolsByCategory[categoryId] = [];
          }
          toolsByCategory[categoryId].push(tool);
        }

        const recommendations = generateRecommendations(toolsByCategory, input);
        return recommendations;
      }),

    savePreferences: protectedProcedure
      .input(
        z.object({
          projectType: z.string().optional(),
          developmentStyle: z.string().optional(),
          scalability: z.string().optional(),
          specificFeatures: z.array(z.string()).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await createUserPreference({
          userId: ctx.user.id,
          projectType: input.projectType,
          developmentStyle: input.developmentStyle,
          scalability: input.scalability,
          specificFeatures: input.specificFeatures ? JSON.stringify(input.specificFeatures) : null,
        });
      }),

    saveRecommendation: protectedProcedure
      .input(
        z.object({
          preferenceId: z.number().optional(),
          recommendedTools: z.array(z.number()),
          matchScores: z.record(z.string(), z.number()).optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await saveRecommendation({
          userId: ctx.user.id,
          preferenceId: input.preferenceId,
          recommendedTools: JSON.stringify(input.recommendedTools),
          matchScores: input.matchScores ? JSON.stringify(input.matchScores) : null,
        });
      }),
  }),
});

export type AppRouter = typeof appRouter;
